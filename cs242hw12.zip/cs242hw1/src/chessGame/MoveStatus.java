package chessGame;

public enum MoveStatus {
	ILLEGAL_MOVE,
	CHECK,
	CHECK_MATE,
	NORMAL_MOVE;
}
